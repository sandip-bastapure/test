var mysql = require('mysql');

var exports = module.exports = {};

var connection = mysql.createConnection({
	host: 'localhost',
	user: 'root',
	password: 'root',
	database: 'test'
});

exports.connectDB = function() {
	console.log('Error connecting to Db');
	connection.connect(function(err) {
		if (err) {
			console.log('Error connecting to Db');
			return;
		}
		console.log('Connection established');
	});

	return connection;
}

exports.closeDB = function (connection) {
		connection.end();
}




