var express = require('express');
var app = express();
var db = require('./db');

var fs = require("fs");

//Display List
app.get('/listUsers', function (req, res) {

	var connection = db.connectDB();

	connection.query('SELECT * from users', function(err, rows, fields) {
		if (!err){
		 	console.log('Users data: ', rows);
		 	res.write(res.statusCode.toString()+'\n');
		 	res.write("User data: \n");
		 	res.end( JSON.stringify(rows));
		} else {
			console.log('Error while performing Query.'+ err);
		}
	});
//	db.closeDB(connection);
});

var server = app.listen(8081, function () {
  var host = server.address().address
  var port = server.address().port
  console.log("Example app listening at http://%s:%s", host, port)
});
